// Set the date we're counting down to
var myBirthday = new Date("Dec 10, 2019 06:12:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var timeBetween = myBirthday - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(timeBetween / (1000 * 60 * 60 * 24));
  var hours = Math.floor((timeBetween % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((timeBetween % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((timeBetween % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById('days').innerHTML = days;
  document.getElementById('hours').innerHTML = hours;
  document.getElementById('minutes').innerHTML = minutes;
  document.getElementById('seconds').innerHTML = seconds;
    
  // If the count down is over, write some text 
  if (timeBetween < 0) {
    clearInterval(x);
    document.getElementsByClassName("countdown")[0].innerHTML = "HAPPY BIRTHDAY!!!";
  }
}, 1000);